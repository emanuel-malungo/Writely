(function(){"use strict";const T="1.0.0",d="Writely AI",g="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",m="openai/gpt-oss-20b",v={enabled:!0,activeTone:"professional",autoSuggest:!0,activeProvider:"groq",groqApiKey:g,groqModel:m,geminiApiKey:"AQ.Ab8RN6KKotQtf74CzYk-gC13TgovAyepcNHSqmDPvSKH7SckAg",geminiModel:"gemini-3.5-flash-lite",apiKey:g,model:m,theme:"dark",customPrompts:[{id:"1",name:"Resumo Executivo",prompt:"Resuma os pontos principais em no máximo 2 frases objetivas."},{id:"2",name:"Resposta Cortês",prompt:"Elabore uma resposta amável e profissional agradecendo a mensagem."}]},b=[{id:"professional",label:"Profissional",description:"Comunicação formal, clara e executiva.",icon:"Briefcase"},{id:"natural",label:"Natural",description:"Comunicação humana, fluida e clara.",icon:"Smile"},{id:"friendly",label:"Amigável",description:"Comunicação cordial, próxima e atenciosa.",icon:"Heart"}];class S{observer;settings;toolbarContainer=null;toolbarFooterEl=null;statusBadge=null;toastNotificationEl=null;statusState="IDLE";statusMessage="";constructor(t,e){this.observer=t,this.settings=e,this.setupKeyboardShortcut()}updateSettings(t){this.settings=t,this.renderStatusBadge(),this.renderToolbar()}setupKeyboardShortcut(){const t=e=>{const o=(e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key==="G"||e.key==="g"||e.code==="KeyG"),n=e.altKey&&(e.key==="W"||e.key==="w"||e.code==="KeyW"),s=e.altKey&&e.shiftKey&&(e.key==="G"||e.key==="g"||e.code==="KeyG");if((o||n||s)&&this.settings.enabled)return e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation(),console.log("[Writely] Atalho de teclado acionado!"),this.triggerImprovement(),!1};window.addEventListener("keydown",t,!0),window.addEventListener("keyup",e=>{(e.ctrlKey||e.metaKey)&&e.shiftKey&&(e.key==="G"||e.key==="g"||e.code==="KeyG")&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())},!0)}renderStatusBadge(t){this.statusBadge||(this.statusBadge=document.createElement("div"),this.statusBadge.id="writely-status-badge",document.body.appendChild(this.statusBadge));const e=this.settings.enabled,o=t?.chatTitle||this.observer.getActiveChat()?.chatTitle,n=b.find(s=>s.id===this.settings.activeTone);this.statusBadge.style.cssText=`
      position: fixed;
      top: 70px;
      right: 12px;
      z-index: 99999;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 7px 12px;
      border-radius: 9999px;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      color: #EDEDED;
      background: #000000;
      border: 1px solid rgba(255, 255, 255, 0.25);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.5);
      cursor: pointer;
      user-select: none;
      transition: all 0.2s ease;
    `,this.statusBadge.innerHTML=`
      <span style="display:inline-block; width:7px; height:7px; border-radius:50%; background-color:${e?"#FFFFFF":"#4a4a4a"}; box-shadow: ${e?"0 0 8px rgba(255,255,255,0.6)":"none"};"></span>
      <span>${d} ${e?"Ativo":"Pausado"}</span>
      ${e&&n?`<span style="opacity:0.75; font-size:11px; color:#a0a0a0;">• ${n.label}</span>`:""}
      ${e&&o?`<span style="opacity:0.85; font-size:10px; background:rgba(255,255,255,0.12); border:1px solid rgba(255,255,255,0.15); padding:2px 6px; border-radius:5px;">${o}</span>`:""}
    `,this.statusBadge.onclick=()=>{chrome.runtime.sendMessage({type:"TOGGLE_EXTENSION",source:"content"})}}renderToolbar(){const t=this.observer.getEditorElement(),e=t?t.closest("footer")||t.parentElement:null;if(!e||!this.settings.enabled){this.removeToolbar();return}e.style.position="relative",(!this.toolbarContainer||!this.toolbarContainer.isConnected)&&(this.toolbarContainer=document.createElement("div"),this.toolbarContainer.id="writely-editor-toolbar",e.appendChild(this.toolbarContainer)),this.toolbarFooterEl=e;const n=this.observer.getEditorText().length>0,s=n||this.statusState!=="IDLE";this.toolbarContainer.style.cssText=`
      position: absolute;
      left: 50%;
      bottom: calc(100% + 8px);
      z-index: 99999;
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      justify-content: center;
      gap: 8px;
      max-width: calc(100% - 24px);
      padding: 6px 10px;
      background: #000000;
      border: 1px solid rgba(255, 255, 255, 0.25);
      border-radius: 10px;
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.5);
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 12px;
      color: #EDEDED;
      user-select: none;
      opacity: ${s?"1":"0"};
      pointer-events: ${s?"auto":"none"};
      transform: translate(-50%, ${s?"0":"4px"});
      transition: opacity 0.18s ease, transform 0.18s ease;
    `;let l="✨ Melhorar com IA",a=!n||this.statusState==="PROCESSING";this.statusState==="PROCESSING"?l="⏳ Melhorando...":this.statusState==="SUCCESS"?(l="✓ Melhorado",a=!1):this.statusState==="ERROR"&&(l="⚠️ Tentar novamente",a=!1),this.toolbarContainer.innerHTML=`
      <div style="display:flex; align-items:center; gap:6px; font-weight:700; color:#FFFFFF; white-space:nowrap;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
        <span>Writely</span>
      </div>

      <div style="height:14px; width:1px; background:rgba(255,255,255,0.2); margin:0 4px;"></div>

      <button id="writely-btn-generate" ${a?"disabled":""} style="
        display: flex;
        align-items: center;
        gap: 6px;
        background: #EDEDED;
        color: #000000;
        border: none;
        padding: 5px 12px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 11px;
        font-family: inherit;
        cursor: ${a?"not-allowed":"pointer"};
        opacity: ${a&&this.statusState==="IDLE"?"0.5":"1"};
        transition: all 0.2s ease;
      ">
        <span>${l}</span>
      </button>

      <span style="font-size:10px; color:#888888; margin-left:2px; white-space:nowrap;">(Alt+W)</span>

      <div style="display:flex; align-items:center; gap:4px; margin-left:auto;">
        ${b.map(u=>`
          <button data-tone="${u.id}" class="writely-tone-btn" style="
            background: ${u.id===this.settings.activeTone?"#EDEDED":"transparent"};
            border: 1px solid ${u.id===this.settings.activeTone?"#EDEDED":"rgba(255,255,255,0.2)"};
            color: ${u.id===this.settings.activeTone?"#000000":"#a0a0a0"};
            padding: 3px 8px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.15s ease;
          ">${u.label}</button>
        `).join("")}
      </div>
    `;const c=this.toolbarContainer.querySelector("#writely-btn-generate");c&&!a&&(c.onclick=()=>this.triggerImprovement()),this.toolbarContainer.querySelectorAll(".writely-tone-btn").forEach(u=>{u.onclick=I=>{const y=I.currentTarget.getAttribute("data-tone");if(y){const x={...this.settings,activeTone:y};this.updateSettings(x),chrome.runtime.sendMessage({type:"SAVE_SETTINGS",payload:x,source:"content"})}}})}async triggerImprovement(){if(this.statusState==="PROCESSING"){console.log("[Writely UI] triggerImprovement chamado mas já está PROCESSING. Ignorado.");return}if(console.log("[Writely UI] === TRIGGER IMPROVEMENT INICIADO ==="),!chrome.runtime?.id){console.error("[Writely UI] Contexto da extensão inválido! Recarregue a página (F5)."),this.showToast("⚠️ Extensão desconectada. Recarregue a página com F5.","error");return}const t=this.observer.getEditorText();if(console.log("[Writely UI] Texto extraído do editor:",JSON.stringify(t)),console.log("[Writely UI] Comprimento do texto:",t.length),!t||t.trim()===""){console.log("[Writely UI] Texto vazio. Mostrando aviso."),this.showToast("Digite uma mensagem no WhatsApp para a IA melhorar!","warning");return}this.statusState="PROCESSING",this.renderToolbar(),console.log("[Writely UI] Estado alterado para PROCESSING.");try{console.log("[Writely UI] Enviando GENERATE_TEXT_REQUEST ao Service Worker...");const e=await chrome.runtime.sendMessage({type:"GENERATE_TEXT_REQUEST",payload:{promptText:t,tone:this.settings.activeTone,contextMessage:this.observer.getActiveChat()?.chatTitle},source:"content"});if(console.log("[Writely UI] Resposta recebida do Service Worker:",JSON.stringify(e)),e&&e.success&&e.data){console.log("[Writely UI] Texto gerado pela IA:",JSON.stringify(e.data)),console.log("[Writely UI] Iniciando substituição no editor...");const o=await this.observer.setEditorText(e.data);if(console.log("[Writely UI] Resultado da substituição:",o),o)this.statusState="SUCCESS",this.renderToolbar(),console.log("[Writely UI] === SUCESSO COMPLETO ==="),setTimeout(()=>{this.statusState="IDLE",this.renderToolbar()},2500);else throw new Error("Não foi possível substituir o conteúdo no editor do WhatsApp.")}else throw console.error("[Writely UI] Resposta sem sucesso:",e),new Error(e?.error||"Ocorreu um erro ao comunicar com a IA.")}catch(e){console.error("[Writely UI] === ERRO NO FLUXO ==="),console.error("[Writely UI] Error name:",e?.name),console.error("[Writely UI] Error message:",e?.message),console.error("[Writely UI] Error completo:",e);const o=this.observer.getEditorText();console.log("[Writely UI] Texto atual no editor após erro:",JSON.stringify(o)),o!==t&&(console.log("[Writely UI] Restaurando texto original..."),await this.observer.setEditorText(t)),this.statusState="ERROR",this.statusMessage=e?.message||"Erro na requisição.",this.renderToolbar(),this.showToast(`⚠️ ${this.statusMessage} (Sua mensagem original foi mantida intacta).`,"error"),setTimeout(()=>{this.statusState="IDLE",this.renderToolbar()},4e3)}}showToast(t,e="info"){this.toastNotificationEl||(this.toastNotificationEl=document.createElement("div"),this.toastNotificationEl.id="writely-toast",document.body.appendChild(this.toastNotificationEl));const o=e==="error"?"#EF4444":e==="warning"?"#F59E0B":"#10B981";this.toastNotificationEl.style.cssText=`
      position: fixed;
      top: 24px;
      right: 24px;
      z-index: 999999;
      background: ${o};
      color: #FFFFFF;
      padding: 10px 16px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 600;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
      max-width: 380px;
      animation: fadeIn 0.3s ease;
    `,this.toastNotificationEl.textContent=t,setTimeout(()=>{this.toastNotificationEl&&(this.toastNotificationEl.remove(),this.toastNotificationEl=null)},4500)}removeToolbar(){this.toolbarContainer&&(this.toolbarContainer.remove(),this.toolbarContainer=null),this.toolbarFooterEl&&(this.toolbarFooterEl.style.position="",this.toolbarFooterEl=null)}}class E{static normalizeContent(t){return t?t.replace(/\r\n/g,`
`).replace(/\r/g,`
`).replace(/[\u200B-\u200D\uFEFF]/g,"").trim():""}static extractEditorText(t){if(!t)return"";const e=t.querySelectorAll('span[data-lexical-text="true"]');if(e.length>0){const n=[];e.forEach(l=>{n.push(l.textContent||"")});const s=n.join("");if(s.length>0)return this.normalizeContent(s)}const o=t.querySelectorAll("p");if(o.length>0){const n=[];return o.forEach(s=>{n.push(s.innerText||s.textContent||"")}),this.normalizeContent(n.join(`
`))}return this.normalizeContent(t.innerText||t.textContent||"")}static selectAllContent(t){const e=window.getSelection();if(!e)return!1;const o=document.createRange();return o.selectNodeContents(t),e.removeAllRanges(),e.addRange(o),!0}static moveCursorToEnd(t){const e=window.getSelection();if(!e)return;const o=document.createRange();o.selectNodeContents(t),o.collapse(!1),e.removeAllRanges(),e.addRange(o)}static sleep(t){return new Promise(e=>setTimeout(e,t))}static verifyContent(t,e){const o=this.extractEditorText(t),n=o===e;return console.log(`[LexicalMutator] Verificação: "${o.substring(0,50)}..." === "${e.substring(0,50)}..." → ${n}`),n}static async mutateEditorContent(t,e){if(!t)return!1;const o=this.normalizeContent(e);console.log("[LexicalMutator] === INICIANDO SUBSTITUIÇÃO ==="),console.log("[LexicalMutator] Texto original no editor:",this.extractEditorText(t)),console.log("[LexicalMutator] Novo texto desejado:",o),t.focus(),await this.sleep(50);try{console.log("[LexicalMutator] Tier 1: Clipboard real + execCommand paste..."),await navigator.clipboard.writeText(o),console.log("[LexicalMutator] Tier 1: Texto escrito no clipboard do sistema."),this.selectAllContent(t),await this.sleep(30);const n=document.execCommand("paste");if(console.log("[LexicalMutator] Tier 1: execCommand paste resultado:",n),await this.sleep(200),this.verifyContent(t,o))return console.log("[LexicalMutator] ✅ Tier 1 (clipboard real) BEM-SUCEDIDO!"),this.moveCursorToEnd(t),!0}catch(n){console.warn("[LexicalMutator] Tier 1 falhou:",n)}try{console.log("[LexicalMutator] Tier 2: ClipboardEvent paste sintético..."),t.focus(),this.selectAllContent(t),await this.sleep(30);const n=new DataTransfer;n.setData("text/plain",o);const s=new ClipboardEvent("paste",{bubbles:!0,cancelable:!0,clipboardData:n});if(t.dispatchEvent(s),await this.sleep(200),this.verifyContent(t,o))return console.log("[LexicalMutator] ✅ Tier 2 (ClipboardEvent paste) BEM-SUCEDIDO!"),this.moveCursorToEnd(t),!0}catch(n){console.warn("[LexicalMutator] Tier 2 falhou:",n)}try{console.log("[LexicalMutator] Tier 3: beforeinput insertFromPaste..."),t.focus(),this.selectAllContent(t),await this.sleep(30);const n=new DataTransfer;if(n.setData("text/plain",o),t.dispatchEvent(new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,inputType:"insertFromPaste",dataTransfer:n})),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!1,inputType:"insertFromPaste",dataTransfer:n})),await this.sleep(200),this.verifyContent(t,o))return console.log("[LexicalMutator] ✅ Tier 3 (beforeinput insertFromPaste) BEM-SUCEDIDO!"),this.moveCursorToEnd(t),!0}catch(n){console.warn("[LexicalMutator] Tier 3 falhou:",n)}try{if(console.log("[LexicalMutator] Tier 4: beforeinput insertReplacementText..."),t.focus(),this.selectAllContent(t),await this.sleep(30),t.dispatchEvent(new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,inputType:"insertReplacementText",data:o})),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!1,inputType:"insertReplacementText",data:o})),await this.sleep(200),this.verifyContent(t,o))return console.log("[LexicalMutator] ✅ Tier 4 (insertReplacementText) BEM-SUCEDIDO!"),this.moveCursorToEnd(t),!0}catch(n){console.warn("[LexicalMutator] Tier 4 falhou:",n)}try{console.log("[LexicalMutator] Tier 5: execCommand insertText..."),t.focus(),this.selectAllContent(t),await this.sleep(30);const n=document.execCommand("insertText",!1,o);if(console.log("[LexicalMutator] Tier 5: execCommand resultado:",n),await this.sleep(200),this.verifyContent(t,o))return console.log("[LexicalMutator] ✅ Tier 5 (execCommand insertText) BEM-SUCEDIDO!"),this.moveCursorToEnd(t),!0}catch(n){console.warn("[LexicalMutator] Tier 5 falhou:",n)}try{console.log("[LexicalMutator] Tier 6: Reconstrução DOM direta (último recurso)..."),t.focus(),t.innerHTML="",o.split(`
`).forEach(l=>{const a=document.createElement("p");if(a.className="selectable-text copyable-text",a.setAttribute("dir","ltr"),a.style.cssText="text-indent: 0px; margin-top: 0px; margin-bottom: 0px;",l.trim()==="")a.appendChild(document.createElement("br"));else{const c=document.createElement("span");c.setAttribute("data-lexical-text","true"),c.className="selectable-text copyable-text",c.textContent=l,a.appendChild(c)}t.appendChild(a)}),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:o})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0,key:"Unidentified"})),t.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0,key:"Unidentified"})),this.moveCursorToEnd(t),await this.sleep(200);const s=this.extractEditorText(t);if(console.log("[LexicalMutator] Tier 6 texto final:",s),s===o)return console.log("[LexicalMutator] ✅ Tier 6 (DOM direto) BEM-SUCEDIDO!"),!0}catch(n){console.warn("[LexicalMutator] Tier 6 falhou:",n)}return console.error("[LexicalMutator] ❌ TODAS AS ESTRATÉGIAS FALHARAM. Substituição não foi possível."),!1}}class C{isReady=!1;currentEditorEl=null;currentChatInfo=null;mutationObserver=null;typingTimeout=null;callbacks;isTyping=!1;lastText="";constructor(t={}){this.callbacks=t}start(){console.log("[Writely Observer] Iniciando observador resiliente do WhatsApp Web..."),this.checkAppReady(),this.setupMutationObserver(),setInterval(()=>{this.resilientFindEditor(),this.resilientDetectActiveChat()},2e3)}stop(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.detachEditorEvents()}checkAppReady(){return(document.getElementById("app")||document.querySelector("._a7-g")||document.querySelector('[role="application"]'))&&!this.isReady&&(this.isReady=!0,console.log("[Writely Observer] WhatsApp Web carregado com sucesso!"),this.callbacks.onAppReady&&this.callbacks.onAppReady()),this.isReady}resilientFindEditor(){let t=document.querySelector('#main footer div[contenteditable="true"]');return t||(t=document.querySelector('footer div[contenteditable="true"][role="textbox"]')),t||(t=document.querySelector('footer div[contenteditable="true"][data-tab]')||document.querySelector('footer div[contenteditable="true"][spellcheck]')),t||(t=document.querySelector('#main div[contenteditable="true"]')),t||(t=document.querySelector('div[contenteditable="true"]')),t!==this.currentEditorEl&&(t?(console.log("[Writely Observer] Editor de mensagem identificado!"),this.currentEditorEl=t,this.attachEditorEvents(t),this.callbacks.onEditorFound&&this.callbacks.onEditorFound(t)):this.currentEditorEl&&(console.log("[Writely Observer] Editor de mensagem desconectado."),this.detachEditorEvents(),this.currentEditorEl=null,this.callbacks.onEditorLost&&this.callbacks.onEditorLost())),this.currentEditorEl}getEditorText(){return this.currentEditorEl||this.resilientFindEditor(),this.currentEditorEl?E.extractEditorText(this.currentEditorEl):""}async setEditorText(t){const e=this.resilientFindEditor();if(!e)return console.warn("[Writely Observer] Não foi possível injetar texto: editor não encontrado."),!1;const o=await E.mutateEditorContent(e,t);return this.handleTypingEvent(),o}resilientDetectActiveChat(){let t=document.querySelector("#main header span[title]")||document.querySelector("#main header div[title]")||document.querySelector('header [role="button"] span[title]');if(t||(t=document.querySelector("#main header h2")||document.querySelector("#main header span")),t&&t.textContent){const e=t.textContent.trim(),n=!!(document.querySelector('#main header span[title*=","]')||document.querySelector('#main header span[title*="você"]'));(!this.currentChatInfo||this.currentChatInfo.chatTitle!==e)&&(this.currentChatInfo={chatTitle:e,isGroup:n,lastActiveTimestamp:Date.now()},console.log(`[Writely Observer] Conversa ativa alterada para: "${e}" (Grupo: ${n})`),this.callbacks.onChatChange&&this.callbacks.onChatChange(this.currentChatInfo))}return this.currentChatInfo}attachEditorEvents(t){t.addEventListener("input",this.handleTypingEvent),t.addEventListener("keyup",this.handleTypingEvent),t.addEventListener("focus",this.handleTypingEvent)}detachEditorEvents(){this.currentEditorEl&&(this.currentEditorEl.removeEventListener("input",this.handleTypingEvent),this.currentEditorEl.removeEventListener("keyup",this.handleTypingEvent),this.currentEditorEl.removeEventListener("focus",this.handleTypingEvent))}handleTypingEvent=()=>{const t=this.getEditorText(),e=t.length>0;this.typingTimeout&&window.clearTimeout(this.typingTimeout);const o={isTyping:e,currentText:t,charCount:t.length,chatTitle:this.currentChatInfo?.chatTitle||"Conversa Desconhecida"};this.callbacks.onTypingStateChange&&(this.isTyping!==e||this.lastText!==t)&&(this.isTyping=e,this.lastText=t,this.callbacks.onTypingStateChange(o)),this.typingTimeout=window.setTimeout(()=>{this.isTyping&&(this.isTyping=!1,this.callbacks.onTypingStateChange&&this.callbacks.onTypingStateChange({...o,isTyping:!1}))},2500)};setupMutationObserver(){const t=document.getElementById("app")||document.body;let e=null;this.mutationObserver=new MutationObserver(()=>{e||(e=window.setTimeout(()=>{e=null,this.checkAppReady(),this.resilientFindEditor(),this.resilientDetectActiveChat()},300))}),this.mutationObserver.observe(t,{childList:!0,subtree:!0})}getActiveChat(){return this.currentChatInfo}getEditorElement(){return this.currentEditorEl}}console.log(`%c[${d}] Content Script v${T} inicializando...`,"color: #10B981; font-weight: bold; font-size: 13px;");let p=v,h=null,r=null;function f(){h=new C({onAppReady:()=>{console.log(`[${d}] App WhatsApp Web pronto.`)},onEditorFound:()=>{r&&r.renderToolbar()},onEditorLost:()=>{r&&r.removeToolbar()},onChatChange:i=>{console.log(`[${d}] Conversa ativa:`,i.chatTitle),r&&r.renderStatusBadge(i),chrome.runtime.sendMessage({type:"CHAT_CHANGED",payload:i,source:"content"}).catch(()=>{})},onTypingStateChange:i=>{chrome.runtime.sendMessage({type:"TYPING_STATUS",payload:i,source:"content"}).catch(()=>{})}}),r=new S(h,p),r.renderStatusBadge(),h.start(),chrome.runtime.sendMessage({type:"GET_SETTINGS",source:"content"}).then(i=>{i&&i.success&&i.data&&(p=i.data,r&&r.updateSettings(p))}).catch(i=>{console.warn(`[${d}] Falha ao buscar configurações:`,i)}),chrome.runtime.sendMessage({type:"WHATSAPP_READY",source:"content"}).catch(()=>{})}chrome.runtime.onMessage.addListener(i=>{console.log(`[${d} Content] Mensagem recebida:`,i.type),i.type==="SETTINGS_RESPONSE"&&i.payload&&(p=i.payload,r&&r.updateSettings(p))}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f()})();
